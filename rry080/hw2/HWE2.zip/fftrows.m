function output=fftrows(input)

output=fft(input,4096,2);


