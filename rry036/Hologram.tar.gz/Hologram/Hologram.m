clc, clear

[img, map, alpha] = imread('Arch1.png');
[x, map] = rgb2ind(img);
# I_2t = 1-double(x);  # target intensity, black motive, white background
I_2t = double(x);  # target intensity, white motive, black background

grid_size = power(2,8);  # no. samplses
holo_size = 0.02;  # [m], hologram size hsould be 2 cm
lbda = 635e-9;  # 600 nm
k = 2*pi/lbda;  # wave number
L = 1e3;  # 100 m
sigma = 1e-2;  #std div, roughly equal to grid size

# for blacking out 0'th order maxima
p_1_sample = holo_size/(grid_size-1);  # distance btwn each sample ping p1
p_2_sample = lbda*L/holo_size;  # distance between each sample point p2
x_vect = -grid_size/2*p_1_sample:p_1_sample:(grid_size/2-1)*p_1_sample;
u_vect = -grid_size/2*p_2_sample:p_2_sample:(grid_size/2-1)*p_2_sample;
[X, Y] = meshgrid(x_vect, x_vect);
[U, V] = meshgrid(u_vect, u_vect);
r_mat_p_1 = sqrt(X.^2+Y.^2); # matrix containing dist to origin p1
r_mat_p_2 = sqrt(U.^2+V.^2);  # matrix containing dist to origin p2
gauss_beam = exp(-r_mat_p_1.^2/sigma^2);

# imshow(gauss_beam)  # change sigma to make it gaussian @ DOE

e_1 = rand(grid_size, grid_size) > 0.5;
for i=0:10
  e_2_tmp = fftshift(fft2(fftshift(e_1)));
  e_2 = sqrt(I_2t).*exp(j*angle(e_2_tmp));
  e_1_tmp = fftshift(ifft2(fftshift(e_2)));
  e_1 = real(e_1_tmp) > 0;
end
fig1 = figure();
plot(real(e_1_tmp), imag(e_1_tmp), 'k.')
DOE = e_1;
f_1 = gauss_beam.*exp(j*k/(2*L)*(X.^2+Y.^2)).*DOE;
f_2 = fftshift(fft2(fftshift(f_1)));

black_out_radius = 8*p_2_sample;
saturation_factor = 2;
I_2 = abs(f_2).^2;
I_2_plot = I_2.*(r_mat_p_2 > black_out_radius);

fig2 = figure();
subplot(1,2,1)
imshow(I_2_plot./(max(max(I_2_plot))));

subplot(1,2,2)
imshow(I_2_plot./(max(max(I_2_plot)))*2);